
public class RekeningBank {
    String nomorRekening;
    String namaPemilik;
    double saldo;

    void tampilkanInfo() {
        System.out.println("Nomor Rekening:\n " + nomorRekening + "Nama Pemilik:\n" + namaPemilik
                + "Saldo:\n" + saldo);
    }

    void setorUang(double jumlah) {
        if (jumlah > 0) {
            saldo += jumlah;
            System.out.println(namaPemilik + "menyetor" + jumlah);
            System.out.println("Saldo sekarang " + saldo);
        }
    }

    void narikUang(double jumlah) {
        if (jumlah > 0 && jumlah <= saldo) {
            saldo -= jumlah;
            System.out.println(namaPemilik + "menarik" + jumlah + "(Berhasil) saldo sekarang" + saldo);
        } else {
            System.out.println(namaPemilik + "menarik" + jumlah + "(Gagal, saldo tidak mencukupi) saldo saat ini" + saldo);
        }
    }

}


